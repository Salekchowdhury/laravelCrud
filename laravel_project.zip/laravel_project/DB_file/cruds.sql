-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 02, 2021 at 12:30 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `cruds`
--

CREATE TABLE `cruds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `car` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cruds`
--

INSERT INTO `cruds` (`id`, `name`, `email`, `car`, `created_at`, `updated_at`) VALUES
(1, 'salek', 'salek@gmail.com', 'Audi', '2021-11-02 04:03:47', '2021-11-02 04:03:47'),
(2, 'salek', 'salek@gmail.com', 'BMW', '2021-11-02 04:13:15', '2021-11-02 04:13:15'),
(3, 'salek chy', 'salek.chy@gmail.com', 'Citroen', '2021-11-02 04:47:56', '2021-11-02 04:47:56'),
(4, 'md salek chy', 'salek.chy11@gmail.com', 'Citroen', '2021-11-02 04:48:11', '2021-11-02 04:48:11'),
(5, 'md salek chy', 'salek.chy11@gmail.com', 'Ford', '2021-11-02 04:48:18', '2021-11-02 04:48:18'),
(6, 'salek', 'salek@gmail.com', 'Ford', '2021-11-02 04:48:24', '2021-11-02 04:48:24'),
(7, 'md salek chy', 'salek.chy@gmail.com', 'Citroen', '2021-11-02 04:48:30', '2021-11-02 04:48:30'),
(8, 'md salek chy', 'salek.chy@gmail.com', 'Citroen', '2021-11-02 04:48:36', '2021-11-02 04:48:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cruds`
--
ALTER TABLE `cruds`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cruds`
--
ALTER TABLE `cruds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
