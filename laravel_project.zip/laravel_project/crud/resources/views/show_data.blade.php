<!doctype html>
<html lang="en">
  <head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Show Data</title>
  </head>
  <body>
 <div class="container">
     <a href="{{url('/add_data')}}" class="btn btn-success my-3">Add Data</a>
 <table class="table">
  <thead>
    <tr>
    <th scope="col">SL#</th>
      <th scope="col">Name</th>
      <th scope="col">email</th>
      <th scope="col">Car</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    @php $n=1; @endphp
      @foreach($showData as $data)
   
        <tr>
        <td>{{$n}}</td>
      <td>{{$data->name}}</td>
      <td>{{$data->email}}</td>
      <td>{{$data->car}}</td>
      <td>
          <a href="{{url('editData/'.$data->id)}}" class="btn btn-success">Edit</a>
          <a href="" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    @php $n++; @endphp
    @endforeach
      
  
   
 
  </tbody>
</table>
{{$showData->links()}}
 </div>
  </body>
</html>