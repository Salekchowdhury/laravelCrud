<h2>This is About Page </h2>

<!-- <a href="{{url('/')}}">Home</a></br>
<a href="{{url('about')}}">About</a></br> -->