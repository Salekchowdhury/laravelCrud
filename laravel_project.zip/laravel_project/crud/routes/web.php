<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers;


//Route::get('/', [sideController::class, 'home']);

//Route::get('/', 'SideController@home');

Route::get('/editData/{id}', 'App\Http\Controllers\SideController@editUserData');
Route::get('/showData', 'App\Http\Controllers\SideController@showUserData');
Route::get('/add_data', 'App\Http\Controllers\SideController@add_data');
Route::post('/store_data', 'App\Http\Controllers\SideController@storeData');


//Route::get('/about', 'App\Http\Controllers\sideController@about');
//Route::get('/about/{nameValue}', 'App\Http\Controllers\sideController@about');
