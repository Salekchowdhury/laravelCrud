<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Add Data</title>
</head>

<body>
    <div class="container">
        <a href="<?php echo e(url('/showData')); ?>" class="btn btn-success my-3">Show Data</a>
        <?php if(Session::has('msg')): ?>
        <p><?php echo e(Session::get('msg')); ?></p>
        <?php endif; ?>
        <form action="<?php echo e(url('/store_data')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label class="form-label">name</label>
                <input type="text" require name="name" class="form-control">

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" require name="email" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Select Your Option</label>
                    <select name="car" require>
                        <option value="0">Select car:</option>
                        <option value="Audi">Audi</option>
                        <option value="BMW">BMW</option>
                        <option value="Citroen">Citroen</option>
                        <option value="Ford">Ford</option>


                    </select>
                </div>



                <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel_project\crud\resources\views/add_user_data.blade.php ENDPATH**/ ?>