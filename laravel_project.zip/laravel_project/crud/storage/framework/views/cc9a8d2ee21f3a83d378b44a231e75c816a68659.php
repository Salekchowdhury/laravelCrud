<h2>This is About Page </h2>

<!-- <a href="<?php echo e(url('/')); ?>">Home</a></br>
<a href="<?php echo e(url('about')); ?>">About</a></br> --><?php /**PATH C:\xampp\htdocs\laravel_project\crud\resources\views/aboutPage.blade.php ENDPATH**/ ?>