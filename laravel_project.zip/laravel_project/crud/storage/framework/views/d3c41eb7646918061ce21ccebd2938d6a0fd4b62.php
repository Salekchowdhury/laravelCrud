<!doctype html>
<html lang="en">
  <head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Show Data</title>
  </head>
  <body>
 <div class="container">
     <a href="<?php echo e(url('/add_data')); ?>" class="btn btn-success my-3">Add Data</a>
 <table class="table">
  <thead>
    <tr>
    <th scope="col">SL#</th>
      <th scope="col">Name</th>
      <th scope="col">email</th>
      <th scope="col">Car</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php $n=1; ?>
      <?php $__currentLoopData = $showData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
        <tr>
        <td><?php echo e($n); ?></td>
      <td><?php echo e($data->name); ?></td>
      <td><?php echo e($data->email); ?></td>
      <td><?php echo e($data->car); ?></td>
      <td>
          <a href="<?php echo e(url('editData/'.$data->id)); ?>" class="btn btn-success">Edit</a>
          <a href="" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    <?php $n++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
  
   
 
  </tbody>
</table>
<?php echo e($showData->links()); ?>

 </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel_project\crud\resources\views/show_data.blade.php ENDPATH**/ ?>