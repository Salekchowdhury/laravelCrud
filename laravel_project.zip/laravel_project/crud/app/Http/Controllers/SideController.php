<?php

namespace App\Http\Controllers;

use App\Models\crud;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;
session_start();

class sideController extends Controller
{
    function home()
    {
        return view('homePage');
    }
    function showUserData()
    {
        //$showData=crud::all();
        //$showData=crud::paginate(5);
        $showData=crud::simplePaginate(5);
        return view('show_data',compact('showData'));
    }
    function add_data()
    {
        return view('add_user_data');
    }
    public function storeData(Request $request)
    {
           $crud =new crud();
           $crud->name =$request->name;
           $crud->email =$request->email;
           $crud->car =$request->car;
           $crud->save();
           //session()->put();
           Session('msg','Data Susscessfulyy Added');
           return redirect()->back();

        //dd($request->all());
    }

    public function editUserData($id=null)
     {
         return $id;
     }
}
